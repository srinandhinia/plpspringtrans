package com.cg.springmvc.controller;

import java.util.List;
import java.util.Map;








import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc.dto.Customer;
import com.cg.springmvc.dto.Transactions;
import com.cg.springmvc.service.IPaymentWalletService;


@Controller
public class MyController 
{
	@Autowired
	IPaymentWalletService paymentwalletservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll() {
		return "home";
	}
	

	@RequestMapping(value="create", method=RequestMethod.GET)
	public String createAccount(@ModelAttribute("my") Customer cust, Map<String,Object> model) {
		System.out.println("in create");
		
		return "createaccount";
		
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertData(@Valid@ModelAttribute("my") Customer cust,BindingResult result, Map<String,Object> model) {
		if(result.hasErrors())
		{
			return "createaccount";
		}
		else
		{
			paymentwalletservice.createAccount(cust);
			return "success";
		}
			
	}
	

	@RequestMapping(value="deposit", method=RequestMethod.GET)
	public String depositAmount() {
		System.out.println("in deposit");
		
		return "deposit";
		
	}
	
	@RequestMapping(value="dodeposit", method=RequestMethod.GET)
	public String depositAmountData(@RequestParam("mbno") String mobNo,@RequestParam("damount") double depamount) 
	{
		if(paymentwalletservice.accountExist(mobNo))
			return "accountnotexist";
		else
		{
			paymentwalletservice.deposit(mobNo, depamount);
			System.out.println("dodeposit() retur success");
			return "success";
		}
		
	}
	
	@RequestMapping(value="withdraw", method=RequestMethod.GET)
	public String withdrawAmount() {
		System.out.println("in withdraw");
		
		return "withdraw";
		
	}
	
	@RequestMapping(value="dowithdraw", method=RequestMethod.GET)
	public String withdrawAmountData(@RequestParam("mobno") String mobileNo,@RequestParam("withdrawamount") double withdamount) 
	{
		if(paymentwalletservice.accountExist(mobileNo))
			return "accountnotexist";
		else
		{
			paymentwalletservice.withdraw(mobileNo, withdamount);
			System.out.println("dowithdraw() return success");
			return "success";
		}
		
		
	}
	
	@RequestMapping(value="checkbalance", method=RequestMethod.GET)
	public String checkbal() {
		System.out.println("in withdraw");
		
		return "checkbalance";
		
	}
	
	@RequestMapping(value="docheckbalance", method=RequestMethod.GET)
	public ModelAndView checkBalInfo(@RequestParam("mobno") String mobileNo)
	{
		if(paymentwalletservice.accountExist(mobileNo))
		{
			return new ModelAndView("accountnotexist");
		}
			
		else
		{
			double bal=paymentwalletservice.checkBalance(mobileNo);
			
			return new ModelAndView("success","custdata",bal);
		}
		
		
	}
	
	@RequestMapping(value="fundtransfer", method=RequestMethod.GET)
	public String fundtransfer() {
		System.out.println("in withdraw");
		
		return "fundtransfer";
		
	}
	@RequestMapping(value="dofundtransfer", method=RequestMethod.GET)
	public String fundTransferData(@RequestParam("senderMobNo") String senderMobileNo,
			@RequestParam("receiverMobNo") String receiverMobileNo,@RequestParam("transferAmount") double transferAmount) 
	{
		

		if(paymentwalletservice.accountExist(senderMobileNo) || paymentwalletservice.accountExist(receiverMobileNo))
			return "accountnotexist";
		else
		{
			paymentwalletservice.fundTransfer(senderMobileNo, receiverMobileNo, transferAmount);;
			System.out.println("dowithdraw() return success");
			return "success";
		}
		
		
	}
	
	@RequestMapping(value="printtransactions", method=RequestMethod.GET)
	public String transactionsData() {
		System.out.println("in trans");
		
		return "printtrans";
		
	}
	
	@RequestMapping(value="doprinttransactions", method=RequestMethod.GET)
	public ModelAndView Ptrans(@RequestParam("mobno") String mobileNo)
	{
		if(paymentwalletservice.accountExist(mobileNo))
		{
			return new ModelAndView("accountnotexist");
		}
			
		else
		{
			List<Transactions> trans = paymentwalletservice.getTransList(mobileNo);
			
			return new ModelAndView("printtranssuccess","trans",trans);
		}
		
		
	}
	
	
	
	

	

}
