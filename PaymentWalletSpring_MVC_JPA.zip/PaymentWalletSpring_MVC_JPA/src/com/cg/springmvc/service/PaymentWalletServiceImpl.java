package com.cg.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;






import com.cg.springmvc.dao.IPaymentWalletDao;
import com.cg.springmvc.dto.Customer;
import com.cg.springmvc.dto.Transactions;

@Service("paymentwalletservice")
@Transactional
public class PaymentWalletServiceImpl implements IPaymentWalletService
{
	
	@Autowired
	IPaymentWalletDao paymentwalletdao;
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		paymentwalletdao.createAccount(customer);
		System.out.println("createAccountSerImpl()");
		
	}

	@Override
	public void deposit(String custMobileNo, double amount) 
	{
		// TODO Auto-generated method stub
		System.out.println("depositSerImpl()");
		paymentwalletdao.deposit(custMobileNo, amount);
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		paymentwalletdao.withdraw(custMobileNo, amount);
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		return paymentwalletdao.checkBalance(custMobileNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		paymentwalletdao.fundTransfer(sender, reciever, amount);
		
	}

	@Override
	public boolean accountExist(String custMobileNo) {
		// TODO Auto-generated method stub
		return paymentwalletdao.accountExist(custMobileNo);
	}

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		// TODO Auto-generated method stub
		return paymentwalletdao.getTransList(mobileNo) ;
	}

}
