package com.cg.springmvc.dao;

import java.util.List;



import com.cg.springmvc.dto.Customer;
import com.cg.springmvc.dto.Transactions;



public interface IPaymentWalletDao
{
	    public void createAccount(Customer customer);
		
		public void deposit(String custMobileNo, double amount);
		
		public void withdraw(String custMobileNo, double amount);
		
		public double checkBalance(String custMobileNo);
		
		public void fundTransfer(String sender, String reciever, double amount);
		
		public boolean accountExist(String custMobileNo);
		
		List<Transactions> getTransList(String mobileNo);

}
